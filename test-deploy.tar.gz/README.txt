Hello from StreamScene
